﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YuluDrums
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PlaySound("basdrum.wav");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PlaySound("hihat.wav");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PlaySound("snare.wav");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            PlaySound("tom1.wav");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            PlaySound("tom2.wav");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            PlaySound("tom3.wav");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            PlaySound("cymbal 1.wav");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            PlaySound("cymbal 2.wav");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            PlaySound("cymbal 3.wav");
        }

        void PlaySound(string filename)
        {
            //自分自身の実行ファイルのパスを取得する
            string appPath = System.Windows.Forms.Application.StartupPath;
            //オーディオファイル名
            string fileName = appPath + "\\sounds\\" + filename;

            //ファイルを開く
            Microsoft.DirectX.AudioVideoPlayback.Audio audio =
                new Microsoft.DirectX.AudioVideoPlayback.Audio(fileName);
            //再生する
            audio.Play();
        }
    }
}
